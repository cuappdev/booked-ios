//
//  MainViewModel.swift
//  Booked
//
//  Created by Alyssa Wang on 9/9/26.
//


import SwiftUI

enum LibraryAvailability: Equatable {
    case open(closesAt: Date)
    case closed(opensAt: Date)

    var isOpen: Bool {
        if case .open = self {
            return true
        }
        return false
    }
}

struct LibraryViewModel {
    let library: Library

    var availability: LibraryAvailability? = nil
    var isFavorite: Bool = false

    var onToggleFavorite: () -> Void = {}
    var onBack: () -> Void = {}
    var onBook: () -> Void = {}

    var chips: [String] {
        [
            library.spaceInfo.library,
            library.spaceInfo.reservationType.label
        ] + library.features.spaceFeatures
    }

    func availabilityText(_ availability: LibraryAvailability) -> (String, Color, String) {
        switch availability {
        case .open(let closesAt):
            return (
                "Open",
                Constants.Colors.bookableAccent,
                "Closes \(closesAt.formatted(.dateTime.hour().minute()))"
            )

        case .closed(let opensAt):
            return (
                "Closed",
                Constants.Colors.closedRed,
                "Opens \(opensAt.formatted(.dateTime.weekday(.abbreviated).hour().minute()))"
            )
        }
    }

    func soundIcon(for level: String) -> String {
        switch level {
        case "Silent":
            return "silent_icon"
        case "Quiet":
            return "quiet_icon"
        default:
            return "full_volume_icon"
        }
    }
}
