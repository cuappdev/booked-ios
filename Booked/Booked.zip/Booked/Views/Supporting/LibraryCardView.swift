//
//  LibraryCardView.swift
//  Booked
//
//  Created by Alyssa Wang on 9/9/26.
//

import SwiftUI

// MARK: - Display helpers

extension Library {
    var spaceTypeLabel: String { spaceInfo.category }

    var soundLevelLabel: String { features.soundLevel.first ?? "—" }

    // MARK: Icons (asset catalog names)

    var spaceTypeIcon: String { "sofa_icon" }

    var soundLevelIcon: String { "full_volume_icon" }

    var collaborativeIcon: String { "person_icon" }

    var featureIcon: String { "sofa_icon" }
}

// MARK: - Card

struct LibraryCardView: View {
    let library: Library
    var isFavorite: Bool = false
    var onToggleFavorite: () -> Void = {}
    var onTap: () -> Void = {}

    private let cornerRadius: CGFloat = 20

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .topTrailing) {
                image
                heartButton
                    .padding(8)
            }
            details
        }
        .background(Constants.Colors.cardSurface)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .stroke(Constants.Colors.cardBorder, lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 3)
        .contentShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .onTapGesture(perform: onTap)
        .accessibilityAddTraits(.isButton)
    }

    // MARK: Image

    private var image: some View {
        Constants.Colors.cardBorder.opacity(0.5)
            .aspectRatio(4 / 3, contentMode: .fit)
            .overlay {
                AsyncImage(url: library.displayImageURL) { phase in
                    switch phase {
                    case .success(let img):
                        img.resizable().scaledToFill()
                    case .failure:
                        Image(systemName: "photo")
                            .font(.title2)
                            .foregroundStyle(Constants.Colors.tertiaryText)
                    default:
                        ProgressView()
                    }
                }
            }
            .clipped()
    }

    private var heartButton: some View {
        Button(action: onToggleFavorite) {
            Image(systemName: isFavorite ? "heart.fill" : "heart")
                .font(.system(size: 18))
                .foregroundStyle(isFavorite ? Color.red : Constants.Colors.bookedGreen)
                .frame(width: 38, height: 38)
                .background(.white.opacity(0.85), in: Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isFavorite ? "Remove from favorites" : "Add to favorites")
    }

    // MARK: Details

    private var details: some View {
        VStack(alignment: .leading, spacing: 4) {
            title
            subtitle
            metaRows
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 16)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var title: some View {
        Text(library.title)
            .fontWeight(.semibold)
            .font(.system(size: 17))
            .foregroundStyle(Constants.Colors.bookedGreen)
            .lineLimit(1)
            .truncationMode(.tail)
    }

    private var subtitle: some View {
        HStack(spacing: 4) {
            Text(library.spaceInfo.library)
                .foregroundStyle(Constants.Colors.secondaryText)
                .font(.system(size: 14))
                .lineLimit(1)
            Text("·")
                .foregroundStyle(Constants.Colors.secondaryText)
            Text(library.spaceInfo.reservationType.label)
                .foregroundStyle(library.spaceInfo.reservationType.isBookable
                                 ? Constants.Colors.bookableAccent
                                 : Constants.Colors.secondaryText)
                .lineLimit(1)
        }
        .font(.system(size: 13))
    }

    private var metaRows: some View {
        VStack(alignment: .leading, spacing: 3) {
            metaRow(icon: library.spaceTypeIcon, text: library.spaceTypeLabel)
            metaRow(icon: library.soundLevelIcon, text: library.soundLevelLabel)
        }
        .padding(.top, 2)
    }

    private func metaRow(icon: String, text: String) -> some View {
        HStack(spacing: 6) {
            Image(icon)
                .renderingMode(.template)
                .resizable()
                .scaledToFit()
                .frame(width: 14, height: 14)
            Text(text)
                .font(.system(size: 12))
                .lineLimit(1)
        }
        .foregroundStyle(Constants.Colors.tertiaryText)
    }
}

#Preview {
    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
        ForEach(Library.sampleData.prefix(4)) { LibraryCardView(library: $0) }
    }
    .padding(16)
    .background(Constants.Colors.creamBg)
}
